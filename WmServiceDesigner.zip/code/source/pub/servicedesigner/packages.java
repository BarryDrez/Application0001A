package pub.servicedesigner;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
// --- <<IS-END-IMPORTS>> ---

public final class packages

{
	// ---( internal utility methods )---

	final static packages _instance = new packages();

	static packages _newInstance() { return new packages(); }

	static packages _cast(Object o) { return (packages)o; }

	// ---( server methods )---




	public static final void createPackageJson (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createPackageJson)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:optional activate
		// [o] field:0:required outputJson
		IDataCursor pipelineCursor = pipeline.getCursor();
		String packageName = IDataUtil.getString( pipelineCursor, "packageName");
		String activate = (String) IDataUtil.get( pipelineCursor, "activate");
		
		IData pkgInput = IDataFactory.create();
		IDataCursor pkgInputCursor = pkgInput.getCursor();
		IDataUtil.put(pkgInputCursor, "package", packageName);
		
		pkgInputCursor.destroy();
		IData pkgOutput = IDataFactory.create();
		
		IData outputJson = IDataFactory.create();
		IDataCursor outputJsonCursor = outputJson.getCursor();
		
		try {
			pkgOutput = Service.doInvoke( "wm.server.packages", "packageCreate", pkgInput);
			IDataUtil.put(outputJsonCursor, "packageCreate", pkgOutput);
		}
		catch( Exception e) {
			throw new ServiceException(e);
		}
		
		IDataCursor pkgOutputCursor = pkgOutput.getCursor();
		String code = IDataUtil.getString(pkgOutputCursor, "code");
		pkgOutputCursor.destroy();
		
		if ("1".equals(code)) {
			if (activate != null && "true".equals(activate)) {
				
				IData activateInput = IDataFactory.create();
				IDataCursor activateInputCursor = activateInput.getCursor();
				IDataUtil.put(activateInputCursor, "$$batchActivate", activate);
				IDataUtil.put(activateInputCursor, "package", packageName);
				activateInputCursor.destroy();
				
				IData activateOutput = IDataFactory.create();
				try {
					activateOutput = Service.doInvoke("pub.servicedesigner.rest_resources", "activatePackage", activateInput);
					IDataUtil.put(outputJsonCursor, "activatePackage", activateOutput);
				}
				catch(Exception e) {
					throw new ServiceException(e);
				}
			}
		}
		
		IDataUtil.put(pipelineCursor, "outputJson", outputJson);
		
		outputJsonCursor.destroy();
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void deletePackageJson (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deletePackageJson)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] field:0:required outputJson
		IDataCursor pipelineCursor = pipeline.getCursor();
		String packageName = IDataUtil.getString( pipelineCursor, "packageName");
		
		IData pkgInput = IDataFactory.create();
		IDataCursor pkgInputCursor = pkgInput.getCursor();
		IDataUtil.put(pkgInputCursor, "package", packageName);
		
		pkgInputCursor.destroy();
		IData pkgOutput = IDataFactory.create();
		
		try{
			pkgOutput = Service.doInvoke( "wm.server.packages", "packageDelete", pkgInput);
		}
		catch( Exception e) {
			throw new ServiceException(e);
		}
		
		IDataUtil.put(pipelineCursor, "outputJson", pkgOutput);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getPackagesJson (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackagesJson)>> ---
		// @sigtype java 3.5
		// [o] field:0:required packageJson
		IData input = null;
		
		IData pkgsOutput = IDataFactory.create();
		try{
			pkgsOutput = Service.doInvoke( "wm.server.packages", "packageList", input );
		}
		catch( Exception e) {
			throw new ServiceException(e);
		}
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		IDataUtil.put(pipelineCursor, "packageJson", pkgsOutput);
		
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

