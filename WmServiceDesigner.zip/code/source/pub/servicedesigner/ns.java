package pub.servicedesigner;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Arrays;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
// --- <<IS-END-IMPORTS>> ---

public final class ns

{
	// ---( internal utility methods )---

	final static ns _instance = new ns();

	static ns _newInstance() { return new ns(); }

	static ns _cast(Object o) { return (ns)o; }

	// ---( server methods )---




	public static final void createNodeJson (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createNodeJson)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:required ns
		// [i] field:0:optional nodeType
		// [i] field:0:optional lockRequired
		// [o] field:0:required outputJson
		IDataCursor pipelineCursor = pipeline.getCursor();
		String packageName = IDataUtil.getString(pipelineCursor, "packageName");
		String ns = IDataUtil.getString(pipelineCursor, "ns");
		String nodeType = IDataUtil.getString(pipelineCursor, "nodeType");
		String lockRequired = IDataUtil.getString(pipelineCursor, "lockRequired");
		pipelineCursor.destroy();
		
		if (nodeType == null || nodeType.trim().length() < 1) {
			nodeType = "interface";
		}
		
		IData input = IDataFactory.create();
		IDataCursor inputCursor = input.getCursor();
		IDataUtil.put(inputCursor, "node_nsName", ns);
		IDataUtil.put(inputCursor, "node_pkg", packageName);
		IDataUtil.put(inputCursor, "node_type", nodeType);
		if (lockRequired != null && lockRequired.trim().length() > 0) {
			IDataUtil.put(inputCursor, "LOCK_REQUIRED", lockRequired);
		}
		
		inputCursor.destroy();
		
		IData output = IDataFactory.create();
		try{
			output = Service.doInvoke("wm.server.ns", "makeNode", input);
		}
		catch(Exception e) {
			throw new ServiceException(e);
		}
		
		IDataUtil.put(pipelineCursor, "outputJson", output);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void deleteNodeJson (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteNodeJson)>> ---
		// @sigtype java 3.5
		// [i] field:0:required ns
		// [i] field:0:optional packageName
		// [i] field:0:optional logical
		// [i] field:0:optional sortOutput
		// [o] field:0:required outputJson
		IDataCursor pipelineCursor = pipeline.getCursor();
		String ns = IDataUtil.getString(pipelineCursor, "ns");
		String packageName = IDataUtil.getString(pipelineCursor, "packageName");
		String logical = IDataUtil.getString(pipelineCursor, "logical");
		String sortOutput = IDataUtil.getString(pipelineCursor, "sortOutput");
		
		boolean sortNodes = false;
		if (sortOutput != null) {
			sortNodes = Boolean.valueOf(sortOutput);
		}
		
		IData input = IDataFactory.create();
		IDataCursor inputCursor = input.getCursor();
		IDataUtil.put(inputCursor, "node_nsName", ns);
		
		if (packageName != null && packageName.trim().length() > 0) {
			IDataUtil.put(inputCursor, "node_pkg", packageName);
		}
		
		if (logical != null && logical.trim().length() > 0) {
			IDataUtil.put(inputCursor, "logical", logical);
		}
		
		inputCursor.destroy();
		
		// output
		IData output = IDataFactory.create();
		try {
			output = Service.doInvoke("wm.server.ns", "deleteNode", input);
		} catch(Exception e) {
			throw new ServiceException(e);
		}
		
		IDataCursor outputCursor = output.getCursor();
		String[] successfulNodes = IDataUtil.getStringArray(outputCursor, "successfulNodes");
		if (successfulNodes != null && successfulNodes.length > 0 && sortNodes) {
			Arrays.sort(successfulNodes);
		}
		
		IDataUtil.remove(outputCursor, "successfulNodes");
		
		IDataUtil.put(outputCursor, "successfulNodes", successfulNodes);
		
		IDataUtil.put(pipelineCursor, "outputJson", output);
		pipelineCursor.destroy();
		outputCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getNodesJson (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNodesJson)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:optional nodePath
		// [i] field:0:optional sortOutput
		// [o] field:0:required nodeJson
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String packageVal = IDataUtil.getString(pipelineCursor, "packageName");
		String nodePathVal = IDataUtil.getString(pipelineCursor, "nodePath");
		String sortOutput = IDataUtil.getString(pipelineCursor, "sortOutput");
		
		boolean sortNodes = false;
		if (sortOutput != null) {
			sortNodes = Boolean.valueOf(sortOutput);
		}
		
		IData nodeInput = IDataFactory.create();
		IDataCursor nodeInputCursor = nodeInput.getCursor();
		IDataUtil.put( nodeInputCursor, "package", packageVal);
		
		if (nodePathVal != null) {
			IDataUtil.put( nodeInputCursor, "interface", nodePathVal);
		}
		
		IData nodesOutput = IDataFactory.create();
		try {
			nodesOutput = Service.doInvoke("wm.server.ns", "getNodeList", nodeInput);
		}
		catch( Exception e) {
			throw new ServiceException(e);
		}
		
		IDataCursor nodesCursor = nodesOutput.getCursor();
		
		IData[]	nodes = IDataUtil.getIDataArray(nodesCursor, "nodeList");
		
		if (nodes != null && nodes.length > 0 && sortNodes) {
			nodes = IDataUtil.sortIDataArrayByKey(nodes,  "node_nsName", IDataUtil.COMPARE_TYPE_COLLATION, false);
		}
		
		IDataUtil.put(pipelineCursor, "nodeList", nodesOutput);
		
		nodeInputCursor.destroy();
		nodesCursor.destroy();
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

